<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guru;
use Illuminate\Support\Facades\Storage;

class GuruController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get gurus
        $gurus = Guru::latest()->paginate(5);

        //render view with gurus
        return view('gurus.index', compact('gurus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('gurus.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate form
        $this->validate($request, [
            'nama'     => 'required|min:5',
            'image'     => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'hp'   => 'required'
        ]);

        //upload image
        $image = $request->file('image');
        $image->storeAs('public/gurus', $image->hashName());

        Guru::create([
            'nama'     => $request->nama,
            'image'     => $image->hashName(),
            'hp'   => $request->hp
        ]);

        //redirect to index
        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Guru $guru)
    {
        return view('gurus.edit', compact('guru'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $guru
     * @return void
     */
    public function update(Request $request, Guru $guru)
    {
        //validate form
        $this->validate($request, [
            'nama'     => 'required|min:5',
            'image'     => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'hp'   => 'required'
        ]);

        //check if image is uploaded
        if ($request->hasFile('image')) {

            //upload new image
            $image = $request->file('image');
            $image->storeAs('public/gurus', $image->hashName());

            //delete old image
            Storage::delete('public/gurus/'.$guru->image);

            //update guru with new image
            $guru->update([
                'nama'     => $request->nama,
                'image'     => $image->hashName(),
                'hp'   => $request->hp
                ]);

        } else {

            //update guru without image
            $guru->update([
                'nama'     => $request->nama,
                'hp'   => $request->hp
            ]);
        }

        //redirect to index
        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Diubah!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Guru $guru)
    {
        //delete image
        Storage::delete('public/gurus/'. $guru->image);

        //delete guru
        $guru->delete();

        //redirect to index
        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
