<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mapel;
use App\Models\Guru;
use App\Models\Pengajar;

class PengajarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get gurus
        $pengajars = Pengajar::latest()->paginate(5);

        //render view with gurus
        return view('pengajars.index', compact('pengajars'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $gurus = Guru::all();
        $mapels = Mapel::all();

        return view('pengajars.create', compact('gurus', 'mapels'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate form
        $this->validate($request, [
            'id_guru'     => 'required',
            'id_mapel'     => 'required',
            'kelas'     => 'required',
            'jam_pelajaran'     => 'required',
        ]);

        Pengajar::create([
            'id_guru'     => $request->id_guru,
            'id_mapel'     => $request->id_mapel,
            'kelas'     => $request->kelas,
            'jam_pelajaran'     => $request->jam_pelajaran,
        ]);

        //redirect to index
        return redirect()->route('pengajars.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Pengajar $pengajar)
    {
        $gurus = Guru::all();
        $mapels = Mapel::all();

        return view('pengajars.edit', compact('gurus', 'mapels', 'pengajar'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pengajar $pengajar)
    {
        //validate form
        $this->validate($request, [
            'id_guru'     => 'required',
            'id_mapel'     => 'required',
            'kelas'     => 'required',
            'jam_pelajaran'     => 'required',
        ]);

        $pengajar->update([
            'id_guru'     => $request->id_guru,
            'id_mapel'     => $request->id_mapel,
            'kelas'     => $request->kelas,
            'jam_pelajaran'     => $request->jam_pelajaran,
         ]);

        //redirect to index
        return redirect()->route('pengajars.index')->with(['success' => 'Data Berhasil Diubah!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pengajar $pengajar)
    {
        $pengajar->delete();

        return redirect()->route('pengajars.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
